const express=require('express')
const app=express()
const mysql=require('mysql')
const path=require('path')
const expressed=path.join(__dirname,"../public")
app.use(express.static(expressed))
var con=mysql.createConnection({
    host:'localhost',
    user:"root",
    password:"",
    database:"logindata"
});
app.use(express.urlencoded({
    extended:true
}))
app.get('/',(req,res) => {
    res.sendFile(__dirname + 'login.html')
});
app.listen(3000,()=>{
    console.log('listning at port 3000')
})
