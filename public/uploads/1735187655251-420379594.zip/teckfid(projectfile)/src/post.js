const express=require("express")

const app=express()
const mysql =require('mysql')
const path =require('path')
app.use(express.urlencoded({
    extended:true
}))
const expressed=path.join(__dirname,'../public')
app.use(express.static(expressed))
var con=mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"",
    database:"techfid"
})
app.post("/submit",(req,res)=>{
    let posthead=req.body.posthead
    let postdescription=req.body.postdescription
    let files=req.body.files
    let image=req.body.images

    con.connect(function(err){
        if(err) throw err;
        console.log("connected");
        var sql="INSERT INTO postdetails (header,description,files,images) VALUES (?,?,?,?)"
        
        con.query(sql, [posthead, postdescription, files, image], function (err, result){
            if(err) throw err;
            console.log("record success")
            res.redirect("techfidhome.html")
        })
    })
    

    
})
app.listen(3000,()=>{
    console.log("listnign at port ")
})




