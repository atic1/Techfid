var http =require("http");
var fs =require('fs');
const express = require('express');
const path = require('path');
const app = express();
const expressed=path.join(__dirname,"../public")
console.log(path.join(__dirname,"../public"))
app.use(express.static(expressed))



// Serve static files from the "public" directory




app.listen(3000,()=>{
  console.log("listning")
})
